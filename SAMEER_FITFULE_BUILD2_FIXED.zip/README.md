# SAMEER FITFULE — Premium Supplement Marketplace

Fresh Android marketplace project for **SAMEER FITFULE**.

## Included marketplace structure
- Premium colorful SAMEER FITFULE branding
- Create Account + Login
- Home, search and category navigation
- A–Z gym supplement categories
- Multiple brands + SAMEER FITFULE own products
- Product details, stock, price, rating placeholder, wishlist
- Cart with remove controls
- Delivery location
- Checkout: SAMEER delivery, delivery partner/app, self pickup
- Payment choices: COD, UPI/Online, Paytm Business/UPI placeholder
- Orders and account screens
- Customer care: 6303836274
- Policies and support
- GitHub Actions workflow that builds a debug APK

## Important production note
The payment choices in this demo are UI flows only. A real Paytm/UPI gateway must use a trusted backend for order creation, credentials and payment verification. Never place payment secrets in the Android APK or GitHub repository.

The app uses marketplace-style navigation and functionality inspired by common ecommerce patterns; it does not copy Amazon branding/assets.
