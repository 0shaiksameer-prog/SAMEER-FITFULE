package com.sameer.fitfule;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static class Product {
        String brand,name,cat,size; int price,stock;
        Product(String b,String n,String c,String s,int p,int st){brand=b;name=n;cat=c;size=s;price=p;stock=st;}
        String key(){return brand+"|"+name;}
    }

    final Product[] products = {
        new Product("MuscleBlaze","Pre Workout 200 Xtreme","PRE-WORKOUT","100 g",799,12),
        new Product("MuscleBlaze","Pre Workout WrathX","PRE-WORKOUT","240 g",1499,8),
        new Product("MuscleBlaze","Creatine Monohydrate","CREATINE","100 g",599,20),
        new Product("MuscleBlaze","Creatine CreAMP","CREATINE","100 g",799,15),
        new Product("MuscleBlaze","Biozyme Performance Whey","WHEY","1 kg",3299,10),
        new Product("MuscleBlaze","Biozyme Whey PR","WHEY","1 kg",2799,14),
        new Product("MuscleBlaze","MB-Vite Daily Multivitamin","MULTIVITAMIN","60 tablets",599,18),
        new Product("MuscleBlaze","Multivitamin for Men","MULTIVITAMIN","60 tablets",699,10),

        new Product("Optimum Nutrition","Gold Standard Pre Workout","PRE-WORKOUT","30 servings",2299,7),
        new Product("Optimum Nutrition","Micronized Creatine Powder","CREATINE","250 g",1799,9),
        new Product("Optimum Nutrition","Gold Standard 100% Whey","WHEY","1 kg",4999,8),
        new Product("Optimum Nutrition","Opti-Men Multivitamin","MULTIVITAMIN","90 tablets",1799,6),

        new Product("GNC","Pre-Workout Amplified","PRE-WORKOUT","30 servings",1999,8),
        new Product("GNC","Creatine Monohydrate","CREATINE","250 g",1899,10),
        new Product("GNC","Pro Performance Whey","WHEY","1 kg",3499,9),
        new Product("GNC","Mega Men Sport","MULTIVITAMIN","90 tablets",1499,7),

        new Product("MyProtein","THE Pre-Workout","PRE-WORKOUT","320 g",2499,6),
        new Product("MyProtein","Creatine Monohydrate","CREATINE","250 g",1599,12),
        new Product("MyProtein","Impact Whey Protein","WHEY","1 kg",2999,11),
        new Product("MyProtein","Alpha Men Multivitamin","MULTIVITAMIN","120 tablets",1399,5),

        new Product("AS-IT-IS Nutrition","PRE WORKOUT","PRE-WORKOUT","100 g",799,15),
        new Product("AS-IT-IS Nutrition","Creatine Monohydrate","CREATINE","250 g",749,22),
        new Product("AS-IT-IS Nutrition","ATOM Whey Protein","WHEY","1 kg",2299,12),
        new Product("AS-IT-IS Nutrition","Multivitamin","MULTIVITAMIN","60 tablets",499,20),

        new Product("Avvatar","Pre Workout","PRE-WORKOUT","30 servings",1299,8),
        new Product("Avvatar","Creatine Monohydrate","CREATINE","100 g",799,12),
        new Product("Avvatar","Whey Protein","WHEY","1 kg",3199,10),
        new Product("Avvatar","Multivitamin","MULTIVITAMIN","60 tablets",699,8),

        new Product("Nakpro","Pre Workout","PRE-WORKOUT","100 g",699,16),
        new Product("Nakpro","Creatine Monohydrate","CREATINE","250 g",699,20),
        new Product("Nakpro","Perform Whey","WHEY","1 kg",1999,14),
        new Product("Nakpro","Multivitamin","MULTIVITAMIN","60 tablets",399,18),

        new Product("MuscleTech","Shatter Elite","PRE-WORKOUT","30 servings",2499,5),
        new Product("MuscleTech","Platinum Creatine","CREATINE","400 g",1999,7),
        new Product("MuscleTech","Nitro-Tech Whey","WHEY","1 kg",4299,6),
        new Product("MuscleTech","Platinum Multivitamin","MULTIVITAMIN","90 tablets",1299,5),

        new Product("Cellucor","C4 Original","PRE-WORKOUT","30 servings",1999,7),
        new Product("Cellucor","Creatine","CREATINE","72 servings",1799,8),
        new Product("Cellucor","COR Performance Whey","WHEY","1 kg",2999,8),
        new Product("Cellucor","Alpha Amino Multi","MULTIVITAMIN","60 tablets",999,6),

        new Product("Universal Nutrition","Animal Fury","PRE-WORKOUT","30 servings",2299,5),
        new Product("Universal Nutrition","Creatine","CREATINE","200 g",1399,6),
        new Product("Universal Nutrition","Ultra Whey Pro","WHEY","1 kg",2799,7),
        new Product("Universal Nutrition","Daily Formula","MULTIVITAMIN","100 tablets",1199,5),

        new Product("MusclePharm","Assault Sport","PRE-WORKOUT","30 servings",1999,6),
        new Product("MusclePharm","Creatine","CREATINE","300 g",1499,8),
        new Product("MusclePharm","Combat 100% Whey","WHEY","1 kg",2999,8),
        new Product("MusclePharm","Core Series Multi","MULTIVITAMIN","90 tablets",1099,6),

        new Product("HealthKart","HK Vitals Pre Workout","PRE-WORKOUT","30 servings",899,15),
        new Product("HealthKart","HK Vitals Creatine","CREATINE","100 g",649,18),
        new Product("HealthKart","HK Vitals Whey Protein","WHEY","1 kg",2299,15),
        new Product("HealthKart","HK Vitals Multivitamin","MULTIVITAMIN","60 tablets",499,20),

        new Product("The Whole Truth","Protein Bar","SNACKS","6 bars",699,10),
        new Product("Wellbeing Nutrition","Melts Multivitamin","MULTIVITAMIN","30 strips",799,8),
        new Product("HealthKart","Fish Oil Omega 3","OMEGA-3","60 softgels",499,12),
        new Product("MuscleBlaze","Mass Gainer XXL","GAINER","3 kg",2499,8),
        new Product("Optimum Nutrition","Serious Mass","GAINER","2.7 kg",4299,5),
        new Product("MyProtein","Essential BCAA","AMINO","250 g",1299,9),
        new Product("MuscleBlaze","BCAA Pro","AMINO","250 g",999,12),
        new Product("AS-IT-IS Nutrition","L-Glutamine","AMINO","250 g",899,10),
        new Product("GNC","L-Carnitine","FAT BURNER","60 capsules",1299,7),
        new Product("MuscleBlaze","Fish Oil Gold","OMEGA-3","60 capsules",699,15),
        new Product("GNC","Fish Oil","OMEGA-3","100 softgels",999,8),
        new Product("MyProtein","Electrolyte Plus","HYDRATION","20 servings",899,10),
        new Product("MuscleBlaze","Shaker Pro","ACCESSORIES","700 ml",349,30),
        new Product("SAMEER FITFULE","Premium Shaker","ACCESSORIES","750 ml",399,30),
        new Product("MuscleBlaze","Super Gainer XXL","GAINER","3 kg",2599,7),
        new Product("MuscleBlaze","L-Carnitine 3000","FAT BURNER","60 capsules",899,10),
        new Product("MuscleBlaze","Fish Oil 1000","OMEGA-3","60 softgels",699,14),
        new Product("MuscleBlaze","Electrolyte Powder","HYDRATION","200 g",499,16),
        new Product("Optimum Nutrition","Amino Energy","AMINO","270 g",2199,7),
        new Product("Optimum Nutrition","Opti-Women","MULTIVITAMIN","60 capsules",1599,6),
        new Product("Optimum Nutrition","Fish Oil Softgels","OMEGA-3","100 softgels",1499,5),
        new Product("GNC","L-Glutamine","AMINO","180 g",1399,7),
        new Product("GNC","Mega Men One Daily","MULTIVITAMIN","60 tablets",1299,8),
        new Product("GNC","Triple Strength Fish Oil","OMEGA-3","60 softgels",1799,5),
        new Product("MyProtein","Pre-Workout Blend","PRE-WORKOUT","250 g",1799,8),
        new Product("MyProtein","Weight Gainer Blend","GAINER","2.5 kg",2999,7),
        new Product("MyProtein","BCAA 2:1:1","AMINO","250 g",1199,10),
        new Product("MyProtein","Omega 3 Softgels","OMEGA-3","100 softgels",999,8),
        new Product("AS-IT-IS Nutrition","Whey Protein Concentrate","WHEY","1 kg",2199,13),
        new Product("AS-IT-IS Nutrition","Mass Gainer","GAINER","3 kg",2299,9),
        new Product("AS-IT-IS Nutrition","Electrolytes","HYDRATION","250 g",599,14),
        new Product("Avvatar","Mass Gainer","GAINER","3 kg",2699,7),
        new Product("Avvatar","L-Carnitine","FAT BURNER","60 capsules",999,8),
        new Product("Avvatar","Omega 3","OMEGA-3","60 softgels",699,10),
        new Product("Nakpro","Impact Whey","WHEY","1 kg",1899,12),
        new Product("Nakpro","Mass Gainer","GAINER","3 kg",1999,11),
        new Product("Nakpro","Electrolyte","HYDRATION","200 g",499,15),
        new Product("MuscleTech","Mass-Tech Elite","GAINER","2.7 kg",4499,5),
        new Product("MuscleTech","Platinum Multivitamin","MULTIVITAMIN","90 tablets",1399,6),
        new Product("Cellucor","Alpha Amino","AMINO","30 servings",1899,6),
        new Product("Cellucor","C4 Sport","PRE-WORKOUT","30 servings",1699,8),
        new Product("Universal Nutrition","Animal Pak","MULTIVITAMIN","30 packs",1999,5),
        new Product("Universal Nutrition","Animal Whey","WHEY","2 kg",4299,5),
        new Product("MusclePharm","BCAA 3:1:2","AMINO","200 g",1199,7),
        new Product("MusclePharm","Glutamine","AMINO","300 g",1399,6),
        new Product("HealthKart","HK Vitals Fish Oil","OMEGA-3","60 softgels",549,15),
        new Product("HealthKart","HK Vitals Electrolytes","HYDRATION","20 servings",399,18),
        new Product("HealthKart","HK Vitals BCAA","AMINO","200 g",699,14),
        new Product("Wellbeing Nutrition","Melts Multivitamin Women","MULTIVITAMIN","30 strips",799,8),
        new Product("Wellbeing Nutrition","Melts Vitamin D3","VITAMIN-D","30 strips",699,10),
        new Product("The Whole Truth","Protein Bar Peanut","SNACKS","6 bars",699,10),
        new Product("The Whole Truth","Protein Bar Dark Chocolate","SNACKS","6 bars",749,9),
        new Product("SAMEER FITFULE","Creatine Monohydrate","CREATINE","250 g",699,25),
        new Product("SAMEER FITFULE","Whey Protein Blend","WHEY","1 kg",2199,20),
        new Product("SAMEER FITFULE","Pre Workout Pro","PRE-WORKOUT","30 servings",999,20),
        new Product("SAMEER FITFULE","Daily Multivitamin","MULTIVITAMIN","60 tablets",499,25),
        new Product("SAMEER FITFULE","Mass Gainer Pro","GAINER","3 kg",2399,15),
        new Product("SAMEER FITFULE","BCAA Recovery","AMINO","250 g",799,18),
        new Product("SAMEER FITFULE","Omega 3","OMEGA-3","60 softgels",599,20),
        new Product("SAMEER FITFULE","Electrolyte Hydration","HYDRATION","20 servings",399,20),
        new Product("SAMEER FITFULE","L-Carnitine","FAT BURNER","60 capsules",799,15),
        new Product("SAMEER FITFULE","Vitamin D3","VITAMIN-D","60 tablets",299,25),
        new Product("SAMEER FITFULE","Protein Bars","SNACKS","6 bars",499,20),
        new Product("SAMEER FITFULE","Whey Isolate Pro","ISOLATE","1 kg",2499,18),
        new Product("SAMEER FITFULE","Vegan Protein","VEGAN PROTEIN","1 kg",1899,16),
        new Product("SAMEER FITFULE","Casein Night Protein","CASEIN","1 kg",2299,12),
        new Product("SAMEER FITFULE","EAA Essential Aminos","EAA","30 servings",899,20),
        new Product("SAMEER FITFULE","L-Glutamine Pure","GLUTAMINE","250 g",699,20),
        new Product("SAMEER FITFULE","Citrulline Malate","CITRULLINE","250 g",799,18),
        new Product("SAMEER FITFULE","Beta Alanine","BETA-ALANINE","200 g",699,18),
        new Product("SAMEER FITFULE","Intra Workout Hydration","INTRA-WORKOUT","30 servings",899,18),
        new Product("SAMEER FITFULE","Protein Cookies","SNACKS","6 cookies",499,20),
        new Product("SAMEER FITFULE","Gym Shaker Pro Max","ACCESSORIES","800 ml",449,30),
    };

    SharedPreferences sp;
    ArrayList<Product> cart=new ArrayList<>();
    HashSet<String> wish=new HashSet<>();
    LinearLayout root,content;
    final int dark=Color.rgb(17,19,24), orange=Color.rgb(255,102,0), green=Color.rgb(21,177,105), purple=Color.rgb(104,67,231), blue=Color.rgb(26,147,214), bg=Color.rgb(246,247,250), red=Color.rgb(207,48,48);

    @Override public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("sameer_fitfule",0); if(sp.getBoolean("logged",false))showHome(); else showWelcome();}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    GradientDrawable gradient(float r,int... colors){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(r);return g;}
    GradientDrawable outline(int c,int line,float r){GradientDrawable g=bg(c,r);g.setStroke(2,line);return g;}
    TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg(c,20));b.setBackgroundTintList((ColorStateList)null);b.setPadding(7,0,7,0);return b;}
    EditText input(String h,int type){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setInputType(type);e.setSingleLine(true);e.setPadding(16,0,16,0);e.setBackground(outline(Color.WHITE,Color.rgb(218,220,225),18));return e;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void add(LinearLayout p,View v,int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(w,h);q.setMargins(l,t,r,b);p.addView(v,q);}
    void weight(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(0,-1,1));}
    void base(){root=col();root.setBackgroundColor(bg);setContentView(root);content=col();ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    void logo(LinearLayout p,int sz){LinearLayout card=col();card.setGravity(Gravity.CENTER);TextView mark=tv("SF",34,Color.WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(gradient(28,orange,purple,green,blue));add(card,mark,Math.min(sz,110),Math.min(sz,110),0,0,0,5);TextView sub=tv("SAMEER FITFULE",9,dark,true);sub.setGravity(Gravity.CENTER);card.addView(sub);add(p,card,sz,sz+22,0,8,0,4);}
    void top(String title,boolean back){LinearLayout bar=row();bar.setPadding(8,5,8,5);bar.setBackgroundColor(Color.WHITE);if(back){Button b=btn("‹",dark);add(bar,b,48,46,0,0,5,0);b.setOnClickListener(v->showHome());}else add(bar,new Space(this),48,46,0,0,5,0);TextView t=tv(title,19,dark,true);weight(bar,t);Button help=btn("HELP",orange);add(bar,help,68,44,5,0,0,0);help.setOnClickListener(v->help());root.addView(bar,new LinearLayout.LayoutParams(-1,56));}
    void showWelcome(){base();LinearLayout p=col();p.setPadding(26,26,26,26);p.setGravity(Gravity.CENTER_HORIZONTAL);logo(p,126);TextView a=tv("SAMEER FITFULE",29,dark,true);a.setGravity(17);add(p,a,-1,46,0,5,0,2);TextView s=tv("PREMIUM FITNESS & SPORTS NUTRITION MARKETPLACE",11,orange,true);s.setGravity(17);add(p,s,-1,34,0,0,0,18);LinearLayout hero=row();hero.setPadding(18,14,18,14);hero.setBackground(gradient(24,dark,purple,blue));TextView h=tv("A–Z SUPPLEMENTS\nMULTIPLE BRANDS\nDELIVERY • ORDERS • SUPPORT",16,Color.WHITE,true);weight(hero,h);TextView badge=tv("SF\nSHOP",13,Color.WHITE,true);badge.setGravity(17);badge.setBackground(bg(orange,22));add(hero,badge,82,82,8,0,0,0);add(p,hero,-1,104,0,0,0,20);Button c=btn("CREATE ACCOUNT",green),l=btn("LOGIN",dark);add(p,c,-1,56,0,5,0,10);add(p,l,-1,56,0,0,0,18);TextView f=tv("✓ Search   ✓ Categories   ✓ Brands   ✓ Wishlist   ✓ Cart   ✓ Checkout",11,Color.GRAY,false);f.setGravity(17);add(p,f,-1,40,0,4,0,0);root.addView(p,new LinearLayout.LayoutParams(-1,-1));c.setOnClickListener(v->createAccount());l.setOnClickListener(v->login());}
    void createAccount(){base();top("Create Account",false);add(content,tv("Create your SAMEER FITFULE account",23,dark,true),-1,42,20,24,20,3);add(content,tv("Use your account for orders, wishlist and delivery details.",13,Color.GRAY,false),-1,30,20,0,20,18);EditText n=input("Full name",1),m=input("Mobile number",2),e=input("Email address",33),p=input("Password (6+ characters)",129);add(content,n,-1,54,20,4,20,9);add(content,m,-1,54,20,0,20,9);add(content,e,-1,54,20,0,20,9);add(content,p,-1,54,20,0,20,18);Button b=btn("CREATE ACCOUNT",green);add(content,b,-1,56,20,0,20,12);b.setOnClickListener(v->{if(n.getText().toString().trim().isEmpty()||m.getText().toString().trim().length()<10||p.getText().toString().length()<6){toast("Enter valid name, mobile and 6+ character password");return;}sp.edit().putString("name",n.getText().toString().trim()).putString("mobile",m.getText().toString().trim()).putString("email",e.getText().toString().trim()).putString("pass",p.getText().toString()).putBoolean("logged",true).apply();showHome();});}
    void login(){base();top("Login",false);add(content,tv("Welcome back 👋",25,dark,true),-1,40,20,28,20,4);EditText m=input("Mobile or email",33),p=input("Password",129);add(content,m,-1,54,20,8,20,10);add(content,p,-1,54,20,0,20,18);Button b=btn("LOGIN",dark);add(content,b,-1,56,20,0,20,12);b.setOnClickListener(v->{String x=m.getText().toString().trim(),y=p.getText().toString();if((x.equals(sp.getString("mobile",""))||x.equals(sp.getString("email","")))&&y.equals(sp.getString("pass",""))){sp.edit().putBoolean("logged",true).apply();showHome();}else toast("Account not found. Create account first.");});}

}